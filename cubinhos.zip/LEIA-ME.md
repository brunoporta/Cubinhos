# Cubinhos - projeto para compilar o APK no GitHub

## Passo a passo (para o ChatGPT ou para voce)
1. Crie um repositorio novo no GitHub (pode ser privado).
2. Envie TODO o conteudo desta pasta para a branch `main`, incluindo a pasta oculta `.github`.
3. Abra a aba **Actions** do repositorio. O fluxo **Build APK** roda sozinho a cada envio
   (ou clique em **Run workflow**).
4. Quando terminar (verde), abra a execucao e baixe o artefato **cubinhos-apk**
   (contem `app-debug.apk`).
5. No celular, permita "instalar apps desconhecidos" e instale o APK.

## Estrutura
- `www/` - o jogo (HTML, manifest, icones)
- `capacitor.config.json` e `package.json` - empacotador Capacitor 6
- `.github/workflows/build-apk.yml` - compila o APK (Node 20, Java 17)

## Observacoes
- O APK gerado e de depuracao (assinado com a chave de debug): serve para instalar e testar.
  Para publicar na Play Store e preciso gerar um APK/AAB de release assinado com sua chave.
- Se o fluxo falhar, copie o log do passo com erro: costuma ser versao de dependencia.
